# BASIC programs for the BBC Micro disc version of Aviator

This folder contains the BASIC programs from the BBC Micro disc version of Aviator.

* [$.AVIA.bin]($.AVIA.bin) shows the game's instructions and then runs $.AVIATOR

* [$.AVIA1.bin]($.AVIA1.bin) shows the game's key controls and then loads the game in $.AVIA?

* [$.AVIATOR.bin]($.AVIATOR.bin) shows the Acornsoft mode 7 loader screen and then runs $.AVIA1

---

_Mark Moxon_