# Annotated source code for the BBC Micro disc version of Aviator

This folder contains the annotated source code for the BBC Micro disc version of Aviator.

* Main source files:

  * [aviator-source.asm](aviator-source.asm) contains the main source for the game

* Other source files:

  * [aviator-disc.asm](aviator-disc.asm) builds the SSD disc image from the assembled binaries and other source files

---

_Mark Moxon_