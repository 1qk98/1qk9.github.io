# Assembled output for the BBC Micro disc version of Aviator

This folder contains the output binaries from the build process for the BBC Micro disc version of Aviator.

It also contains [compile.txt](compile.txt), which contains the output from the assembly process. This is very useful when debugging the build process.

---

_Mark Moxon_