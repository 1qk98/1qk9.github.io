# Compiled game discs for the BBC Micro disc version of Aviator

This folder contains the SSD disc images for the BBC Micro disc version of Aviator, as produced by the build process. There is one SSD file for each supported release. These SSD images can be loaded into an emulator like JSBeeb or BeebEm, or into a real BBC Micro using a device like a Gotek.

---

_Mark Moxon_